# Memory.md — Build Progress Log

> Not created at project start. Start filling this in once coding begins. Update it at the end of every work session (or every AI coding session) so a new chat/tool can pick up context instantly instead of re-reading the whole codebase or guessing.

## How to Use This File
- Keep entries short and factual — status, not narrative.
- Always update **Current Phase**, **Completed**, and **Next Steps** before ending a session.
- Log **Key Decisions** any time you deviate from Architecture.md/Rules.md/Phases.md, with the reason.
- Log **Known Issues** so they aren't silently rediscovered later.
- Never delete history — append new entries below old ones.

---

## Current Phase
Phase 1 — Project Setup *(update this line each session)*

## Completed
- (nothing yet)

## In Progress
- (nothing yet)

## Next Steps
- Set up repo structure per Architecture.md
- Initialize backend and frontend scaffolding

## Key Decisions Log
| Date | Decision | Reason |
|---|---|---|
| — | — | — |

## Known Issues / Blockers
- (none yet)

## Session Log
### Session 1 — [date]
- What was done:
- What broke / had to be fixed:
- What's left for next session:
